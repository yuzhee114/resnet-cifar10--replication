# ResNet-56 depth experiment

王梓嫣 · 9–15 November 2026

This folder holds my part of the replication: ResNet-56 (0.85 M parameters) on
CIFAR-10, trained from scratch with the group's shared trainer, unchanged.
Seed 0 is complete; seeds 1 and 2 are scheduled and will be added here.

## Experimental setup

Every run uses the group trainer at the commit that introduced `--seed`,
`--log-csv`, `--run-csv` and `--config-out`, with the same recipe the group ran
for ResNet-20: batch size 128, SGD with initial learning rate 0.1, momentum 0.9
and weight decay 0.0001, 45,000 training and 5,000 validation images,
random horizontal flips and 32×32 padded random crops. The learning rate is
divided by 10 after epoch 82 and again after epoch 123, i.e. at 32k and 48k of
the paper's 64k iterations. No warm-up is used: the paper only warms up
ResNet-110 and ResNet-1202. The checkpoint with the highest validation accuracy
is evaluated once on the official 10,000-image test set, so the test set never
takes part in model selection.

Runs used Windows 11, Python 3.10.9, PyTorch 2.5.1+cu121, torchvision
0.20.1+cu121, NumPy 1.26.4 and an NVIDIA GeForce RTX 2060 (6 GB). cuDNN ran in
deterministic mode (`cudnn.deterministic=True`, `cudnn.benchmark=False`) and the
data loader used `num_workers=0`, so seed-to-seed differences come from weight
initialisation and data order rather than from kernel selection or loader
scheduling.

## Results

| Seed | Best epoch | Validation acc. | Test acc. | Test error | Wall clock |
| --- | --- | --- | --- | --- | --- |
| 0 | 149 | 92.760% | 92.540% | 7.460% | 253.8 min |

Reference values for ResNet-56 on CIFAR-10: 6.97% test error in Table 6 of
He et al. (2016), and 6.61% in the upstream PyTorch implementation this code is
based on.

## Where the gap to 6.97% comes from

Seed 0 is 0.49 percentage points above the paper. The difference is systematic,
not noise, and it applies to every model in the replication:

- **Fewer parameter updates.** 45,000 images at batch size 128 make 352
  iterations per epoch, so 164 epochs is 57,728 updates, about 10% short of the
  64,000 the paper's schedule is defined on. Reaching 64,000 updates at this
  batch size would need about 182 epochs.
- **Normalisation.** The trainer normalises with fixed per-channel mean and
  standard deviation, while the paper describes subtracting the per-pixel mean
  of the training set.

The same two deviations are visible in the group's ResNet-20 run, which landed
at 9.13% against the paper's 8.75% (+0.38 pp). Because both deviations are
identical for every depth, the comparison across depths stays fair — which is
what this experiment is for.

## Reproduction

From the repository root, with CIFAR-10 already in `./data`:

```powershell
powershell -ExecutionPolicy Bypass -File scripts/run_resnet56_seeds.ps1 -Seeds 0
```

which expands to

```powershell
python -u trainer.py --arch=resnet56 --epochs=164 --lr-milestones=82,123 `
    --warmup-iters=0 --seed=0 --val-split=5000 --batch-size=128 -j 0 `
    --save-dir=checkpoints --log-csv=epoch_metrics.csv `
    --config-out=config.json --run-csv=run_metrics.csv
```

run from inside `seed0/`, so that `./data` and the output files land next to the
metrics. `scripts/run_resnet56_seeds.ps1` skips a seed whose `epoch_metrics.csv`
already has 164 rows, so it is safe to restart.

Post-processing (summary table, figures, weekly report) is one command:

```powershell
powershell -ExecutionPolicy Bypass -File scripts/postprocess.ps1
```

## Files

| Path | Content |
| --- | --- |
| `seed0/config.json` | resolved configuration, torch/CUDA versions, GPU, split sizes |
| `seed0/epoch_metrics.csv` | one row per epoch: train/val loss and accuracy, LR, wall clock |
| `seed0/run_metrics.csv` | one row per finished run: test error, wall clock |
| `seed0/final_evaluation.txt` | tail of the console log, including the 10k test evaluation |
| `seed0/status.log` | wall-clock start and finish |
| `results/per_seed.csv` | per-seed table |
| `results/summary.csv` | mean ± sd across seeds, with the delta to Table 6 |
| `figures/resnet56_training_curves.png` | training/validation loss and validation accuracy |
| `figures/depth_comparison.png` | test error vs depth, paper curve plus our measured points |

## Pending

Seeds 1 and 2 will be added as `seed1/` and `seed2/` with the same layout once
the GPU is free again; `results/` and `figures/` are regenerated from whatever
seeds are present, so they will pick the new runs up automatically.
